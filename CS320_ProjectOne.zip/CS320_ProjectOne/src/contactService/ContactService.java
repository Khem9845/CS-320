/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: Provides in-memory management for Contact objects. Supports adding
 * unique contacts, deleting by contactId, retrieving by contactId, and updating
 * allowed fields (firstName, lastName, phone, address).
 */
package contactService;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) throw new IllegalArgumentException("contact is null");
        String id = contact.getContactId();
        if (contacts.containsKey(id)) throw new IllegalArgumentException("duplicate contactId");
        contacts.put(id, contact);
    }

    public void deleteContact(String contactId) {
        if (contactId == null) throw new IllegalArgumentException("contactId is null");
        if (!contacts.containsKey(contactId)) throw new IllegalArgumentException("contactId not found");
        contacts.remove(contactId);
    }

    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null) throw new IllegalArgumentException("contactId is null");
        Contact c = contacts.get(contactId);
        if (c == null) throw new IllegalArgumentException("contactId not found");

        if (firstName != null) c.setFirstName(firstName);
        if (lastName != null) c.setLastName(lastName);
        if (phone != null) c.setPhone(phone);
        if (address != null) c.setAddress(address);
    }
}
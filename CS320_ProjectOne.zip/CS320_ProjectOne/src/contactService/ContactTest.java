/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: JUnit tests to verify Contact object validation rules and setter behavior.
 */
package contactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void testValidContact() {
        Contact c = new Contact("1", "Khem", "Khati", "3179841156", "3217 Clary Blvd South Dr");
        assertEquals("1", c.getContactId());
        assertEquals("Khem", c.getFirstName());
        assertEquals("Khati", c.getLastName());
        assertEquals("3179841156", c.getPhone());
        assertEquals("3217 Clary Blvd South Dr", c.getAddress());
    }

    @Test
    void testInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "A", "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "A", "B", "1234567890", "Addr"));
    }

    @Test
    void testInvalidFirstLastName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", null, "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "ABCDEFGHIJK", "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", null, "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "ABCDEFGHIJK", "1234567890", "Addr"));
    }

    @Test
    void testInvalidPhoneAndAddress() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", null, "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "123", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "123456789X", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "A", "B", "1234567890", "X".repeat(31)));
    }

    @Test
    void testSettersValidAndInvalid() {
        Contact c = new Contact("1", "A", "B", "1234567890", "Addr");

        c.setFirstName("New");
        c.setLastName("Last");
        c.setPhone("0987654321");
        c.setAddress("New Address");

        assertEquals("New", c.getFirstName());
        assertEquals("Last", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("New Address", c.getAddress());

        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("ABCDEFGHIJK"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("111"));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress("X".repeat(31)));
    }
}
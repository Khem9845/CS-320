/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: JUnit tests to verify ContactService add/delete/update behaviors and error handling.
 */
package contactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    void testAddAndGetContact() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "A", "B", "1234567890", "Addr"));
        assertNotNull(service.getContact("1"));
    }

    @Test
    void testAddNullThrows() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.addContact(null));
    }

    @Test
    void testAddDuplicateThrows() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "A", "B", "1234567890", "Addr"));
        assertThrows(IllegalArgumentException.class, () ->
                service.addContact(new Contact("1", "C", "D", "0987654321", "Addr2")));
    }

    @Test
    void testDeleteContact() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "A", "B", "1234567890", "Addr"));
        service.deleteContact("1");
        assertNull(service.getContact("1"));
    }

    @Test
    void testDeleteMissingThrows() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }

    // ? NEW TEST: delete with null id
    @Test
    void testDeleteNullIdThrows() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact(null));
    }

    @Test
    void testUpdateAllFields() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "A", "B", "1234567890", "Addr"));

        service.updateContact("1", "New", "Last", "0987654321", "New Address");
        Contact c = service.getContact("1");

        assertEquals("New", c.getFirstName());
        assertEquals("Last", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("New Address", c.getAddress());
    }

    @Test
    void testUpdateSomeFieldsOnly() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "A", "B", "1234567890", "Addr"));

        service.updateContact("1", null, "Z", null, null);
        Contact c = service.getContact("1");

        assertEquals("A", c.getFirstName());
        assertEquals("Z", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("Addr", c.getAddress());
    }

    @Test
    void testUpdateMissingThrows() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () ->
                service.updateContact("999", "A", null, null, null));
    }

    // ? NEW TEST: update with null id
    @Test
    void testUpdateNullIdThrows() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () ->
                service.updateContact(null, "A", "B", "1234567890", "Addr"));
    }
}
/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: JUnit tests verifying Appointment object rules (ID, date not past, description)
 * and setter validation behavior.
 */
package appointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentTest {

    @Test
    void testValidAppointment() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a = new Appointment("1", future, "Checkup");
        assertEquals("1", a.getAppointmentId());
        assertEquals("Checkup", a.getDescription());
        assertEquals(future, a.getAppointmentDate());
    }

    @Test
    void testInvalidId() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, future, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", future, "Desc"));
    }

    @Test
    void testInvalidDateNullOrPast() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "Desc"));

        Date past = new Date(System.currentTimeMillis() - 60_000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", past, "Desc"));
    }

    @Test
    void testInvalidDescription() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", future, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", future, "X".repeat(51)));
    }

    @Test
    void testSettersValidAndInvalid() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a = new Appointment("1", future, "Desc");

        Date future2 = new Date(System.currentTimeMillis() + 120_000);
        a.setAppointmentDate(future2);
        a.setDescription("New Desc");

        assertEquals(future2, a.getAppointmentDate());
        assertEquals("New Desc", a.getDescription());

        Date past = new Date(System.currentTimeMillis() - 60_000);
        assertThrows(IllegalArgumentException.class, () -> a.setAppointmentDate(past));
        assertThrows(IllegalArgumentException.class, () -> a.setDescription("X".repeat(51)));
    }
}
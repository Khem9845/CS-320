/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: Defines the Appointment object with required appointmentId (max 10),
 * appointmentDate (not null, cannot be in the past), and description (max 50).
 * appointmentId is not updatable. Uses java.util.Date and before(new Date()) check.
 */
package appointmentService;

import java.util.Date;

public class Appointment {
    private final String appointmentId; // not updatable
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        validateId(appointmentId);
        validateDate(appointmentDate);
        validateDescription(description);

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public String getAppointmentId() { return appointmentId; }
    public Date getAppointmentDate() { return appointmentDate; }
    public String getDescription() { return description; }

    // Not required by rubric to update, but included to increase coverage & demonstrate validation.
    public void setAppointmentDate(Date appointmentDate) {
        validateDate(appointmentDate);
        this.appointmentDate = appointmentDate;
    }

    // Not required by rubric to update, but included to increase coverage & demonstrate validation.
    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    private static void validateId(String id) {
        if (id == null || id.length() > 10) throw new IllegalArgumentException("appointmentId invalid");
    }

    private static void validateDate(Date date) {
        if (date == null) throw new IllegalArgumentException("appointmentDate null");
        if (date.before(new Date())) throw new IllegalArgumentException("appointmentDate in past");
    }

    private static void validateDescription(String desc) {
        if (desc == null || desc.length() > 50) throw new IllegalArgumentException("description invalid");
    }
}
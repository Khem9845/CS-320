/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: In-memory Appointment management. Supports add (unique appointmentId),
 * delete by appointmentId, and retrieve by appointmentId.
 */
package appointmentService;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointment == null) throw new IllegalArgumentException("appointment is null");
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) throw new IllegalArgumentException("duplicate appointmentId");
        appointments.put(id, appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null) throw new IllegalArgumentException("appointmentId is null");
        if (!appointments.containsKey(appointmentId)) throw new IllegalArgumentException("appointmentId not found");
        appointments.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
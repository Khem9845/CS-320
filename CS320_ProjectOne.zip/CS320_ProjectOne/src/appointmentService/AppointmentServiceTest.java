/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: JUnit tests verifying AppointmentService behaviors (add unique, delete, errors).
 */
package appointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentServiceTest {

    @Test
    void testAddAndGetAppointment() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 60_000);

        service.addAppointment(new Appointment("1", future, "Desc"));
        assertNotNull(service.getAppointment("1"));
    }

    @Test
    void testAddNullThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    @Test
    void testAddDuplicateThrows() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 60_000);

        service.addAppointment(new Appointment("1", future, "Desc"));
        assertThrows(IllegalArgumentException.class, () ->
                service.addAppointment(new Appointment("1", future, "Desc2")));
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 60_000);

        service.addAppointment(new Appointment("1", future, "Desc"));
        service.deleteAppointment("1");
        assertNull(service.getAppointment("1"));
    }

    @Test
    void testDeleteMissingThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("999"));
    }

    // ? NEW TEST ? delete with null ID
    @Test
    void testDeleteNullIdThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class,
                () -> service.deleteAppointment(null));
    }
}
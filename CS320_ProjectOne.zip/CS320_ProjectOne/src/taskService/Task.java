/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: Defines the Task object with validation rules for taskId (max 10),
 * name (max 20), and description (max 50). taskId is required and not updatable.
 */
package taskService;

public class Task {
    private final String taskId; // not updatable
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        validateId(taskId);
        validateName(name);
        validateDescription(description);

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    public void setName(String name) {
        validateName(name);
        this.name = name;
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    private static void validateId(String id) {
        if (id == null || id.length() > 10) throw new IllegalArgumentException("taskId invalid");
    }

    private static void validateName(String name) {
        if (name == null || name.length() > 20) throw new IllegalArgumentException("name invalid");
    }

    private static void validateDescription(String desc) {
        if (desc == null || desc.length() > 50) throw new IllegalArgumentException("description invalid");
    }
}
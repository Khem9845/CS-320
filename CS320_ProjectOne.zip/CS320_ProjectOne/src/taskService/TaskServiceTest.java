/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: JUnit tests to verify TaskService add/delete/update behaviors and error handling.
 */
package taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddAndGetTask() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Name", "Desc"));
        assertNotNull(service.getTask("1"));
    }

    @Test
    void testAddNullThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    @Test
    void testAddDuplicateThrows() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Name", "Desc"));
        assertThrows(IllegalArgumentException.class,
                () -> service.addTask(new Task("1", "Name2", "Desc2")));
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Name", "Desc"));
        service.deleteTask("1");
        assertNull(service.getTask("1"));
    }

    @Test
    void testDeleteMissingThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
    }

    // ? NEW TEST ? delete with null ID
    @Test
    void testDeleteNullIdThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask(null));
    }

    @Test
    void testUpdateTaskAllFields() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Name", "Desc"));

        service.updateTask("1", "New", "New Desc");
        Task t = service.getTask("1");

        assertEquals("New", t.getName());
        assertEquals("New Desc", t.getDescription());
    }

    @Test
    void testUpdateTaskOneField() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Name", "Desc"));

        service.updateTask("1", null, "Only Desc");
        Task t = service.getTask("1");

        assertEquals("Name", t.getName());
        assertEquals("Only Desc", t.getDescription());
    }

    @Test
    void testUpdateMissingThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class,
                () -> service.updateTask("999", "A", "B"));
    }

    // ? NEW TEST ? update with null ID
    @Test
    void testUpdateNullIdThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class,
                () -> service.updateTask(null, "Name", "Desc"));
    }
}
/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: JUnit tests that verify Task object validation rules,
 * including task ID, name, description constraints, and setter behavior.
 */
package taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testValidTask() {
        Task t = new Task("1", "Task Name", "Task description");
        assertEquals("1", t.getTaskId());
        assertEquals("Task Name", t.getName());
        assertEquals("Task description", t.getDescription());
    }

    @Test
    void testInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc"));
    }

    @Test
    void testInvalidNameAndDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "X".repeat(21), "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", "X".repeat(51)));
    }

    @Test
    void testSetters() {
        Task t = new Task("1", "Name", "Desc");
        t.setName("New Name");
        t.setDescription("New Desc");

        assertEquals("New Name", t.getName());
        assertEquals("New Desc", t.getDescription());

        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription("X".repeat(51)));
    }
}
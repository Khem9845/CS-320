/**
 * Author: Khem Khatiwada
 * Course: CS-320 Software Test, Automation & QA
 * Assignment: Project One
 * Description: In-memory Task management. Supports add (unique ID), delete by taskId,
 * retrieve by taskId, and update allowed fields (name, description).
 */
package taskService;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) throw new IllegalArgumentException("task is null");
        String id = task.getTaskId();
        if (tasks.containsKey(id)) throw new IllegalArgumentException("duplicate taskId");
        tasks.put(id, task);
    }

    public void deleteTask(String taskId) {
        if (taskId == null) throw new IllegalArgumentException("taskId is null");
        if (!tasks.containsKey(taskId)) throw new IllegalArgumentException("taskId not found");
        tasks.remove(taskId);
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    public void updateTask(String taskId, String name, String description) {
        if (taskId == null) throw new IllegalArgumentException("taskId is null");
        Task t = tasks.get(taskId);
        if (t == null) throw new IllegalArgumentException("taskId not found");

        if (name != null) t.setName(name);
        if (description != null) t.setDescription(description);
    }
}